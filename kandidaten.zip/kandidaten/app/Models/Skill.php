<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Skill
 * @package App
 */
class Skill extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $table = "skills";
}
