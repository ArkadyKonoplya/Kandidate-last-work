<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class OpportunityList
 * @package App\Models
 */
class OpportunityList extends Model
{
    protected $table = 'opportunity_list';
}