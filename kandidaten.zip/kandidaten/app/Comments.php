<?php

namespace App;

use App\Models\Comment;

/**
 * Class Comments
 * @package App
 * @deprecated
 */
class Comments extends Comment {}