<?php

namespace App;

use App\Models\Skill;

/**
 * Class Skills
 * @package App
 * @deprecated
 */
class Skills extends Skill {}
