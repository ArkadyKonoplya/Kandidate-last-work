<?php

namespace App;

use App\Models\Account;

/**
 * Class Accounts
 * @package App
 * @deprecated
 */
class Accounts extends Account {}