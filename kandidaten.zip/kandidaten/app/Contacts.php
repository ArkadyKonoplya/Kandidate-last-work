<?php

namespace App;

use App\Models\Contact;

/**
 * Class Contacts
 * @package App
 * @deprecated
 */
class Contacts extends Contact {}