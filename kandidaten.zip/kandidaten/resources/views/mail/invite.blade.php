<html>
<head></head>
<body>
Hey,
<br><br>
You was invited to join kandidaten.org. <br>
Just open this link in your browser <a href="{{$inviteLink}}">{{$inviteLink}}</a>
<br>
<br>
Best regards, kandidaten.org.
</body>
</html>