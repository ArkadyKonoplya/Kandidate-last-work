<html>
<head></head>
<body>
<p>{{$content}}</p>
</body>
</html>